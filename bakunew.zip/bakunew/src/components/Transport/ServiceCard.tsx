{address && (
    <div className="flex items-start mb-2">
      <MapPin size={16} className="mr-2 mt-1 text-baku-primary flex-shrink-0" />
      <span className="text-sm">{address}</span>
      {coordinates && (
        <a 
          href={`https://www.google.com/maps/dir/?api=1&destination=${coordinates.lat},${coordinates.lng}`}
          target="_blank"
          rel="noopener noreferrer"
          className="ml-2 text-sm text-blue-600 hover:text-blue-800"
        >
          Get Directions
        </a>
      )}
    </div>
  )}